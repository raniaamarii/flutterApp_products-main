package com.example.flutterapp_products_p2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
